`timescale 1ns/1ps

module vga_sync(
    input  logic       pixel_clk,     // 25 MHz
    input  logic       rst,
    output logic       hsync,
    output logic       vsync,
    output logic       video_on,
    output logic [9:0] x,
    output logic [9:0] y,
    output logic       frame_tick
);

    // Horizontal Timings
    localparam H_DISPLAY       = 640;
    localparam H_BACK_PORCH    = 48;
    localparam H_FRONT_PORCH   = 16;
    localparam H_SYNC          = 96;
    localparam H_TOTAL         = H_DISPLAY + H_BACK_PORCH + H_FRONT_PORCH + H_SYNC - 1;

    localparam HSYNC_START     = H_DISPLAY + H_FRONT_PORCH;
    localparam HSYNC_END       = H_DISPLAY + H_FRONT_PORCH + H_SYNC - 1;

    // Vertical Timings
    localparam V_DISPLAY       = 480;
    localparam V_FRONT_PORCH   = 10;
    localparam V_SYNC          = 2;
    localparam V_BACK_PORCH    = 33;
    localparam V_TOTAL         = V_DISPLAY + V_FRONT_PORCH + V_SYNC + V_BACK_PORCH - 1;

    localparam VSYNC_START     = V_DISPLAY + V_FRONT_PORCH;
    localparam VSYNC_END       = V_DISPLAY + V_FRONT_PORCH + V_SYNC - 1;

    // Counters
    logic [9:0] h_reg, h_next;
    logic [9:0] v_reg, v_next;

    logic hsync_reg, vsync_reg;

    always_ff @(posedge pixel_clk or posedge rst) begin
        if (rst) begin
            h_reg     <= 0;
            v_reg     <= 0;
            hsync_reg <= 1;
            vsync_reg <= 1;
        end else begin
            h_reg     <= h_next;
            v_reg     <= v_next;
            hsync_reg <= ~((h_reg >= HSYNC_START) && (h_reg <= HSYNC_END));
            vsync_reg <= ~((v_reg >= VSYNC_START) && (v_reg <= VSYNC_END));
        end
    end

    // Counter logic
    always_comb begin
        if (h_reg == H_TOTAL)
            h_next = 0;
        else
            h_next = h_reg + 1;

        if (h_reg == H_TOTAL) begin
            if (v_reg == V_TOTAL)
                v_next = 0;
            else
                v_next = v_reg + 1;
        end else begin
            v_next = v_reg;
        end
    end

    // video region
    assign video_on = (h_reg < H_DISPLAY) && (v_reg < V_DISPLAY);

    // outputs
    assign hsync = hsync_reg;
    assign vsync = vsync_reg;
    assign x = h_reg;
    assign y = v_reg;
    
    assign frame_tick = (h_reg == H_TOTAL) && (v_reg == V_TOTAL);

endmodule