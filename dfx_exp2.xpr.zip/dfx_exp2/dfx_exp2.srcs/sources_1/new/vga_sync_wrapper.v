`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 05/29/2026 07:27:40 PM
// Design Name: 
// Module Name: vga_sync_wrapper
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module vga_sync_wrapper(

    input         pixel_clk,
    input         rst,

    output        hsync,
    output        vsync,

    output        video_on,

    output  [9:0] x,
    output  [9:0] y,

    output        frame_tick

);

    vga_sync VGA_SYNC(
        .pixel_clk(pixel_clk),     
        .rst(rst),
        .hsync(hsync),
        .vsync(vsync),
        .video_on(video_on),
        .x(x),
        .y(y),
        .frame_tick(frame_tick)
    );
    
endmodule
